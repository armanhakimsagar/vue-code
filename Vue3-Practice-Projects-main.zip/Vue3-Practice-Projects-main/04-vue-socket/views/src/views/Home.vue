<template>
  <div class="mx-auto h-[89%] mt-16 max-w-7xl relative">

  </div>
</template>