<template>
    <page-components title="Dashboard">Content goes here</page-components>
</template>

<script setup>
import PageComponents from "../components/PageComponents.vue";
</script>

<style scoped>

</style>
