<template>
  <div class="overflow-hidden text-black bg-[#f3f3f3] p-4 h-screen">
    <div class="absolute w-80 h-56 rounded-full bg-[#a6ddf0] blur-[72px]" :style="{top: '-18%', right: '0'}"></div>
    <div class="absolute w-80 h-56 rounded-full bg-[#a6ddf0] blur-[72px]" :style="{top: '36%', left: '-8rem'}"></div>
    <router-view/>
  </div>
</template>

<script>

</script>